# Bar Loader - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/LYrNQPd](https://codepen.io/josetxu/pen/LYrNQPd).

Insipred by this image from Pinterest:  
https://www.pinterest.com/pin/14425661292261254/